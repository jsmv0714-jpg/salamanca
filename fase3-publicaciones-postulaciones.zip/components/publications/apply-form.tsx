"use client";

import { useActionState } from "react";
import { Field, FormError, inputClass, primaryButtonClass } from "../ui/form";
import type { FormState } from "../../lib/validation";
import { applyCopy } from "../../lib/publications";

export type ApplyDefaults = {
  cv_url: string;
  portfolio_url: string;
  linkedin_url: string;
  phone: string;
};

export default function ApplyForm({
  action,
  typeCode,
  defaults,
}: {
  action: (state: FormState, formData: FormData) => Promise<FormState>;
  typeCode: string;
  defaults: ApplyDefaults;
}) {
  const [state, formAction, pending] = useActionState(action, {} as FormState);
  const copy = applyCopy(typeCode);
  const isInternship = typeCode === "internship";

  const text = (key: keyof ApplyDefaults | "message") => {
    const sent = state.values?.[key];
    if (typeof sent === "string") return sent;
    return key === "message" ? "" : defaults[key];
  };
  const consented = state.values?.data_consent === "on";
  const err = (key: string) => state.fieldErrors?.[key];

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <FormError message={state.error} />

      <Field label={copy.message} htmlFor="message" hint={copy.hint} error={err("message")} required>
        <textarea id="message" name="message" rows={5} maxLength={2000} defaultValue={text("message")} className={inputClass} />
      </Field>

      {isInternship ? (
        <>
          <Field
            label="Enlace a tu hoja de vida"
            htmlFor="cv_url"
            error={err("cv_url")}
            hint="Debe estar abierto a cualquiera que tenga el enlace (por ejemplo, en Drive con acceso por enlace)."
          >
            <input id="cv_url" name="cv_url" type="text" inputMode="url" placeholder="https://" defaultValue={text("cv_url")} className={inputClass} />
          </Field>
          <Field label="Portafolio (opcional)" htmlFor="portfolio_url" error={err("portfolio_url")}>
            <input id="portfolio_url" name="portfolio_url" type="text" inputMode="url" placeholder="https://" defaultValue={text("portfolio_url")} className={inputClass} />
          </Field>
          <Field label="LinkedIn (opcional)" htmlFor="linkedin_url" error={err("linkedin_url")}>
            <input id="linkedin_url" name="linkedin_url" type="text" inputMode="url" placeholder="https://" defaultValue={text("linkedin_url")} className={inputClass} />
          </Field>
          <p className="text-xs text-unis-gray">Comparte al menos uno de los tres enlaces.</p>
        </>
      ) : (
        <Field label="Sitio web o enlace con más información (opcional)" htmlFor="portfolio_url" error={err("portfolio_url")}>
          <input id="portfolio_url" name="portfolio_url" type="text" inputMode="url" placeholder="https://" defaultValue={text("portfolio_url")} className={inputClass} />
        </Field>
      )}

      <Field label="Teléfono de contacto (opcional)" htmlFor="phone" error={err("phone")}>
        <input id="phone" name="phone" type="tel" maxLength={50} defaultValue={text("phone")} className={inputClass} />
      </Field>

      <div>
        <label className="flex items-start gap-2 text-xs text-unis-gray">
          <input
            type="checkbox"
            name="data_consent"
            defaultChecked={consented}
            className="mt-0.5 h-4 w-4 shrink-0 rounded border-unis-lightgray text-unis-red focus:ring-unis-red"
          />
          <span>
            Autorizo que mis datos y los enlaces que comparto se entreguen a quien publicó esta oferta y a la
            Universidad de Salamanca Colombia, únicamente para gestionar esta solicitud.
          </span>
        </label>
        {err("data_consent") ? <p className="mt-1 text-xs font-medium text-red-700">{err("data_consent")}</p> : null}
      </div>

      <button type="submit" disabled={pending} className={`${primaryButtonClass} w-full`}>
        {pending ? "Enviando..." : copy.button}
      </button>
    </form>
  );
}
